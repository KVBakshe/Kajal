package FunctionLibrary;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CreateUserInDB {

public  void createUser(String username, int currency, int usertype) {
Connection conn = null;
Statement stmt = null;



try{

Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String USER = "sa";
String PASS = "!@#$%A1";
String URL="jdbc:sqlserver://10.75.102.5:1402;DatabaseName=Casino";
conn = DriverManager.getConnection(URL,USER,PASS);
stmt = conn.createStatement();
String query=
"IF NOT EXISTS(SELECT UserID FROM dbo.tb_UserAccount WHERE LoginName = '"+username+"')"+
"BEGIN "+
"DECLARE "+ 
" @rServerID int"+
", @rLoginName varchar(20)"+
", @rPassword varchar(20)"+
", @rBalance int"+
", @rIdentifierOut varchar(36)"+
", @rUserType int"+
", @iCount int"+
", @cLoginName varchar(20)"+
", @MachineIdentifier int"+
", @Currency int"+ 



" exec sp_RegisterNewUser @ServerID = 5002, "+
"@Currency = "+currency+","+
"@UserType ="+usertype+", "+
"@LoginName = '"+username+"',"+
"@Password ='test', "+
"@Email ='cartman@southpark.com', "+
"@FN ='Eric', "+
"@LN ='Cartman',"+
" @WrkTel ='5698659', "+
"@HomeTel ='4464654', "+
"@Fax ='4646666',"+
"@Addr1 ='25 South Park Street', "+
" @Addr2 ='South Park', "+
"@City ='South Park',"+
"@Country ='USA', "+
"@Province ='Colarado', "+
"@Zip ='1234',"+
"@IDNumber ='6901205121085', "+ 
"@Occupation ='Scholar',"+
"@Sex ='M', "+
"@DOB ='1969/01/20', "+
"@Alias ='Fat boy',"+
"@IdentifierIn =null,"+
"@EventID =29, "+
"@ModuleID =24, "+
"@ChangeAmt =100000,"+
"@CreditLimit =0,"+
"@MachineIdentifier=0,"+
"@HDIdentifier =null,"+
"@Creator = 1, "+
"@IdentifierOut =@rIdentifierOut output"+
" END";


stmt.executeUpdate(query);
System.out.println("Player Inserted");
stmt.close();
conn.close();
}catch(SQLException se){

se.printStackTrace();
}catch(Exception e){

e.printStackTrace();
}finally{

try{
if(stmt!=null)
stmt.close();
}catch(SQLException se2){
}
try{
if(conn!=null)
conn.close();
}catch(SQLException se){
se.printStackTrace();
}
}

}
}