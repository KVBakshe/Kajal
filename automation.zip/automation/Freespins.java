import org.openqa.selenium.WebDriver;
 
import org.openqa.selenium.chrome.ChromeDriver;
 
public class Freespins {
 
         public static void main(String [] args) throws InterruptedException{
                  
                  System.setProperty("webdriver.chrome.driver", "D:/SeleniumEnvironment/chromedriver_win32/chromedriver.exe");
                  WebDriver driver = new ChromeDriver();
                  driver.get("https://mobilewebserver9-mobiletesting02.installprogram.eu/MobileWebGames/game/mgs/9_3_1_6524?moduleID=12772&clientID=50300&gameName=thunderstruckIIDesktop&gameTitle=Thunderstruck%20II&LanguageCode=en&clientTypeID=40&casinoID=5007&lobbyName=IslandParadise&loginType=InterimUPE&lobbyURL=https://mobilewebserver9-MobileTesting02.installprogram.eu/Lobby/en/IslandParadise/Games/3ReelSlots&xmanEndPoints=https://mobilewebserver9-MobileTesting02.installprogram.eu/XMan/x.x&bankingURL=https://mobilewebserver9-MobileTesting02.installprogram.eu/Lobby/en/IslandParadise/Banking&routerEndPoints=&isPracticePlay=false&username=player15&password=test&host=Mobile&apicommsenabled=false&launchtoken=&version=");
driver.findElement(By.xpath("//*[@id='txtSpin']")).click();
WebElement Balance = driver.findElement(By.id("//*[@id='txtBalanceVal']"));
String Basebal=Balance.getText();
System.out.println("Base Game Balance "+Balance);
driver.findElement(By.xpath("//*[@id='txtSpin']")).click();
WebElement FreespinBalance =driver.findElement(By.xpath("//*[@id='txtBalance']"));
String FSbal=FreespinBalance.getText();



                  driver.close();
           }
}